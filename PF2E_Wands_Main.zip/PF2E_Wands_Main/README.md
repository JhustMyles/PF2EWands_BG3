Adds wands with spells based on the hit TTRPG Pathfiner 2E! Dependent on the PF2E Conversion Mod and based on the work of DPH Kraken and Instant Mirage. Made in collaboration with SilentBrad, Darkpulse99, and Ralha.



IN DEVELOPMENT 



Download: https://mod.io/g/baldursgate3/m/pathfinder-2e-wands-in-development#description

Legal

This mod uses trademarks and/or copyrights owned by Paizo Inc., used under Paizo's Community Use Policy. We are expressly prohibited from charging you to use or access this content. This mod is not published, endorsed, or specifically approved by Paizo. For more information about Paizo Inc. and Paizo products, visit paizo.com.

